document.addEventListener("DOMContentLoaded", () => {
  const loginForm = document.getElementById("loginForm");
  const registerForm = document.getElementById("registerForm");
  const logoutLink = document.getElementById("logoutLink");
  const messageBox = document.getElementById("message");

  // ✅ Show message in UI
  const showMessage = (msg, color = "red") => {
    if (messageBox) {
      messageBox.innerText = msg;
      messageBox.style.color = color;
    }
  };

  // 🔐 Register logic
  if (registerForm) {
    registerForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const data = new FormData(registerForm);
      const payload = {
        username: data.get("username"),
        email: data.get("email"),
        password: data.get("password"),
      };

      try {
        const res = await fetch("/api/register", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });

        const result = await res.json();
        if (res.ok) {
          showMessage(result.message, "green");
          registerForm.reset();
          setTimeout(() => (window.location.href = "login.html"), 1000);
        } else {
          showMessage(result.message);
        }
      } catch (err) {
        showMessage("Registration failed.");
      }
    });
  }

  // 🔓 Login logic
  if (loginForm) {
    loginForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const data = new FormData(loginForm);
      const payload = {
        username: data.get("username"),
        password: data.get("password"),
      };

      try {
        const res = await fetch("/api/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });

        const result = await res.json();
        if (res.ok) {
          showMessage(result.message, "green");
          loginForm.reset();
          sessionStorage.setItem("isLoggedIn", "true");
          setTimeout(() => (window.location.href = "home.html"), 1000);
        } else {
          showMessage(result.message);
        }
      } catch (err) {
        showMessage("Login failed.");
      }
    });
  }

  // 🔚 Logout
  if (logoutLink) {
    logoutLink.addEventListener("click", (e) => {
      e.preventDefault();
      sessionStorage.removeItem("isLoggedIn");
      window.location.href = "login.html";
    });
  }

  // 🎯 Active page highlight
  const currentPage = window.location.pathname.split("/").pop().toLowerCase();

document.querySelectorAll("nav a").forEach((link) => {
  const href = link.getAttribute("href").toLowerCase();
  if (href === currentPage) {
    link.style.color = "black";
    link.style.fontWeight = "bold";
    link.style.textDecoration = "underline"; // Optional
  }
});


  // 👁️ Toggle password visibility
  const toggleIcons = document.querySelectorAll(".password-container i");

  toggleIcons.forEach((icon) => {
    icon.addEventListener("click", () => {
      const input = icon.previousElementSibling;
      if (input.type === "password") {
        input.type = "text";
        icon.classList.remove("fa-eye-slash");
        icon.classList.add("fa-eye");
      } else {
        input.type = "password";
        icon.classList.remove("fa-eye");
        icon.classList.add("fa-eye-slash");
      }
    });
  });
});
