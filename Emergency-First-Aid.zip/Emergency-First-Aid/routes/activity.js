import express from 'express';
import Activity from '../models/Activity.js';

const router = express.Router();

router.post('/log', async (req, res) => {
  if (!req.session.user) return res.status(401).json({ message: 'Please login' });

  const { action, details } = req.body;

  try {
    const newActivity = new Activity({
      username: req.session.user.username,
      action,
      details
    });
    await newActivity.save();
    res.status(201).json({ message: 'Activity logged' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to log activity' });
  }
});

export default router;
