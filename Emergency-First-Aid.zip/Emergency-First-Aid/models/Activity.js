import mongoose from 'mongoose';

const activitySchema = new mongoose.Schema({
  username: String,
  action: String,
  details: String,
  timestamp: { type: Date, default: Date.now }
});

export default mongoose.model('Activity', activitySchema);
